<div class="info-value">
    <?php echo $options['value']; ?>
</div>