<input type="file" name="bf-import-file-input" id="bf-import-file-input" class="bf-import-file-input">

<input type="button" class="bf-import-upload-btn button" value="Import" >